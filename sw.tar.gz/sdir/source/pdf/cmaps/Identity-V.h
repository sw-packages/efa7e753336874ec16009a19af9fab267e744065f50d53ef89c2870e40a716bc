/* This is an automatically generated file. Do not edit. */

/* Identity-V */

static pdf_cmap cmap_Identity_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "Identity-V",
	/* usecmap */ "Identity-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	0, 0, NULL, /* ranges */
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
